export const environment = {
  production: true,
  apiURL : 'https://api-uat-ezycommerce.ezyflight.se/api', 

};
