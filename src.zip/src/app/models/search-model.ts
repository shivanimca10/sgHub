

export class SearchDataModel{
    private currency: string ;
    private languageCode: string ;
    private confirmationNumber: string ;
    private bookingLastName: string ;
    private withApisInfos: boolean ;
    private isModified: boolean  ;
    private isManage: boolean  ;
    private includeCancelledSegments:boolean  ;
    private historicUsername: string ;
    private travelAgent: TravelAgent  ;
    private receiptLanguageCode: string  ;
    private digest: string ;
    constructor(currency: string,languageCode: string,confirmationNumber: string,bookingLastName: string,withApisInfos: boolean,
        isModified: boolean,isManage: boolean,includeCancelledSegments:boolean,historicUsername: string,travelAgent: TravelAgent,
        receiptLanguageCode: string,digest: string ){
            this.currency = currency;
            this.languageCode = languageCode;
            this.confirmationNumber = confirmationNumber;
            this.bookingLastName = bookingLastName;
            this.withApisInfos = withApisInfos;
            this.isModified = isModified;
            this.isManage = isManage;
            this.includeCancelledSegments = includeCancelledSegments;
            this.historicUsername = historicUsername;
            this.receiptLanguageCode = receiptLanguageCode;
            this.digest = digest; 
            this.travelAgent = travelAgent
    }
  }

  export class TravelAgent{
    private username: string;
    private password: string;
    private hashed: boolean;
    private iataCode: string;
    private role: string;
    constructor (username: string, password: string, hashed: boolean, iataCode: string,  role: string){
        this.username = username;
        this.password = password;
        this.hashed = hashed;
        this.iataCode = iataCode;
        this.role = role;
    }
  }