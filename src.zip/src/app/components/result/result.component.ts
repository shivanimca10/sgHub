import { Component, Input, OnInit } from '@angular/core'; 
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators,ReactiveFormsModule} from '@angular/forms';  


@Component({
  selector: 'ResultComponent',
  templateUrl: './result.component.html',
  //styleUrls: ['./home.component.scss'],
  
})
export class ResultComponent implements OnInit{
  @Input() flightData = [];

  ngOnInit(): void {
    console.log(this.flightData);
  }

}