import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators,ReactiveFormsModule} from '@angular/forms'; 
import { flightService } from '../../services/flights.service';
import { SearchDataModel, TravelAgent } from 'src/app/models/search-model';


@Component({
  selector: 'SearchComponent',
  templateUrl: './search.component.html', 
})
export class SearchComponent implements OnInit{
  title = 'Search';
  SourceCity:any;
  DestinationCity:any;
 
  cities:any;
  availableFlights:any;
  departureDate :any; 
  returnDate : any;
  ShowResult :boolean = false;
  ShowReturnDate :boolean = false;


  searchForm   = new FormGroup({
    TravelType: new FormControl('', Validators.required),
    SourceCity: new FormControl('' ),
    DestinationCity: new FormControl('' ),
    departureDate: new FormControl(''  ),
    returnDate: new FormControl(''  )
  });


   constructor (private fService : flightService , private route: Router){
    this.departureDate = new Date().toISOString().split('T')[0];
    this.returnDate = new Date().toISOString().split('T')[0];
     this.loadCities();
   }
   ngOnInit(){
    
   }
 
  get f(){
    return this.searchForm.controls;
  }
  
  loadCities(){  
    debugger;
      this.fService.getAirports().subscribe(
      (response) => {           
         this.cities = response['airports'];  
      },
      (error) => {    
         //error handling code
         //loading sample cities in case of error 
         this.cities = this.fService.getSampleAirports();
      }

     );
  }

  search(){ 
    this.changeCity();
    // if(this.f.departureDate.value == this.f.returnDate.value){       
    //   alert("Departure date should be before return date");
    //   return;
    // }
    let travelType = this.f.TravelType.value; 
    let source  =  this.f.SourceCity.value;
    let destination  =  this.f.DestinationCity.value;
    let searchData = this.prepareSearchData();

     this.fService.getAvailableFlights(searchData).subscribe(
      (response) => {    
        if(response != null){
         this.availableFlights = response ; 
         this.ShowResult = false; 
        }
      },
      (error) => {  
          this.getSampleFlightData(); 
         this.ShowResult = true;    
         
      }

     );
  }
 
  changeTravelType(e :any) {
    //console.log(e.target.value);
  }
    
  changeCity( ){ 
    if(this.f.SourceCity.value == this.f.DestinationCity.value){       
      alert("Source and destination cities cannot be same");
      return;
    }
  }

  prepareSearchData(){
    let travelAgentData = new TravelAgent('TestUser','Password',true,'','')
    let data = new SearchDataModel ('','','','',true, false,false,false,'',travelAgentData, '','');
    return data;
  }


  getSampleFlightData(){
    //sampledata
    this.availableFlights = [
      {
        "flightNumber": "53424",
        "departure": "8:30 AM", 
        "arrival":"11:45 AM",
        "destinationCity": "Delhi",
        "price": "4370",
      },
      {
        'flightNumber': "56278",
        'departure': "7:00 AM", 
        'arrival':"9:30 AM",
        'destinationCity': "Chennai",
        "price": "3670",
      },
      {
        'flightNumber': "12166",
        'departure': ":20 PM", 
        'arrival':"9:45 PM",
        'destinationCity': "Cochin",
        "price": "3970",
      }
    ];
  }

}
