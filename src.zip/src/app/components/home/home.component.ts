import { Component } from '@angular/core';

@Component({
  selector: 'homeComponent',
  templateUrl: './home.component.html',
  //styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  title = 'Home';
}
