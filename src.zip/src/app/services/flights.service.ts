import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { environment } from "src/environments/environment"; 


@Injectable({providedIn : "root"})
export class flightService{
    totalAngularPackages : any;
    errorMessage :string = ""; 
    apiURL  = environment.apiURL;
    resultData : any =[];
    constructor(private http: HttpClient) { }

    getAvailableFlights(searchData:any){ 
        //let postData   = JSON.stringify(searchData);
        return this.http.get<any>(this.apiURL + '/getAvailableFlights'   
            ) ; 
    }

    getAirports(){
        return this.http.get<any>(this.apiURL + '/v1/AirportOriginsWithConnections/en-us' ,
          {  headers: {'Content-Type': 'application/json',
            'Tenant-Identifier':'9d7d6eeb25cd6083e0df323a0fff258e59398a702fac09131275b6b1911e202d'} } 
            ) ;
        
    }
    

  
  
  
    getSampleAirports(){ 
        let cities =  
          {
            'airports': [
              {
                'connections': [
                  {
                    'name': 'Incheon International Airport',
                    'code': 'ICN',
                    'currency': 'USD',
                    'countryCode': 'GUM'
                  }
                ],
                'name': 'A.B. Won Pat International Airport',
                'code': 'GUM',
                'currency': 'USD',
                'countryCode': 'GUM'
              },
              {
                'connections': [
                  {
                    'name': 'Ivujivik Airport',
                    'code': 'YIK',
                    'currency': 'CAD',
                    'countryCode': 'CAN'
                  },
                  {
                    'name': 'Salluit Airport',
                    'code': 'YZG',
                    'currency': 'CAD',
                    'countryCode': 'CAN'
                  }
                ],
                'name': 'Akulivik Airport',
                'code': 'AKV',
                'currency': 'CAD',
                'countryCode': 'CAN'
              },
              {
                "connections": [
                  {
                    "name": "Pierre Elliott",
                    "code": "YUL",
                    "currency": "USD",
                    "countryCode": "MEX"
                  }
                ],
                "name": "Cancun International Airport",
                "code": "CUN",
                "currency": "USD",
                "countryCode": "MEX"
              },
              {
                "connections": [
                  {
                    "name": "Dublin International Airport",
                    "code": "DUB",
                    "currency": "ZAR",
                    "countryCode": "ZAF"
                  },
                  {
                    "name": "O.R. Tambo International Airport",
                    "code": "JNB",
                    "currency": "ZAR",
                    "countryCode": "ZAF"
                  }
                ],
                "name": "Cape Town International Airport",
                "code": "CPT",
                "currency": "ZAR",
                "countryCode": "ZAF"
              }
            ]
          }
          
         return cities;
    
      }
    
    

}